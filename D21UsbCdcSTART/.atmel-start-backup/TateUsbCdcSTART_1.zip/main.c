#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//init LED

	/* Replace with your application code */
	while (1) {
		//toggle LED
		//delay 500ms
	}
}
